#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <set>

std::vector<std::string> first;
std::vector<std::string>::iterator it;
std::set<std::string> second;
std::vector<std::string> Gs;
std::vector<std::string> Ts;

void RecPermute(std::string soFar, std::string rest){
	if(rest ==""){
		first.push_back(soFar);
		Ts.push_back(soFar);
		Gs.push_back(soFar);
	}else{
		for (int i = 0; i < rest.length(); ++i)
		{
			std::string next = soFar + rest[i];
			if (second.find(next)!=second.end())
			{
			}else{
				std::string remain = rest.substr(0,i)+rest.substr(i+1);
				second.insert(next);
				RecPermute(next,remain);
			}
		}
	}
}

int main(){
	int m,g,k,s;
	char space;
	std::cin >> m;
	std::string s1, s2,s3;
	std::string Cs;
	
	for (int i = 0; i < m; ++i)
	{
        std::cin >> g;
        std::cin >> k;
	  getline(std::cin, s3);
	  getline(std::cin, s2);
		  for (int i = 0; i < k; ++i)
		  {
		  	Cs+='C';
		  }
	for (int i = 0; i < g-k; ++i)
	{
		s1+=s2[i];
	}

	  RecPermute("",s1+Cs);
		second.clear();

	 s = first.size();
	 std::cout << s*3+1 << '\n' << s2 << '\n';

	for (int i =0; i<Gs.size();i++)
	{
		std::replace( Gs[i].begin(), Gs[i].end(), 'C', 'G'); // replace all 'x' to 'y'
		std::replace( Ts[i].begin(), Ts[i].end(), 'C', 'T'); // replace all 'x' to 'y'
    		std::cout << first[i] << '\n';
    		std::cout << Gs[i] << '\n';
    		std::cout << Ts[i] << '\n';
	}

	Gs.clear();
	Ts.clear();
	first.clear();
	s1 = "";
	}
	return 0;
}